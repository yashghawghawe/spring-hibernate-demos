package com.car.CarInventory;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import java.text.NumberFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);
    static int choice = 0;
    static Car car = new Car();

    public static void main(String[] args) {
        try {
            StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
            Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();
            SessionFactory factory = meta.getSessionFactoryBuilder().build();
            Session session = factory.openSession();
            Transaction t = session.beginTransaction();
            System.out.println("*******Welcome to Yash Automobiles**********");
            System.out.println();
            System.out.println("Select From The Below Menu");
            System.out.println("1.Add Car Details");
            System.out.println("2.Get All Car Details");
            System.out.println("3.Delete Car Details");
            System.out.println("4.Update Car Details");
            System.out.println("5.Exit");
            try {
                System.out.print("Enter Your Choice : ");
                choice = sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Please Enter the input in Number form");
            }
            while (choice != 5) {
                switch (choice) {
                    case 1:
                        System.out.println("Enter The Car Details");
                        System.out.print("make : ");
                        car.setMake(sc.next() + "\n");
                        System.out.print("model : ");
                        car.setModel(sc.next() + "\n");
                        System.out.print("year : ");
                        car.setYear(sc.nextInt());
                        System.out.print("sales price ($) : ");
                        car.setSalesPrice(sc.nextFloat());
                        session.save(car);
                        t.commit();
                        System.out.println("Details SuccessFully Saved!");
                        System.out.println();
                        System.out.println("What do you want to next ?  : ");
                        System.out.print("Enter Your Choice : ");
                        choice = sc.nextInt();
                        break;
                    case 2:
                        Query<Car> query = session.createQuery("from Car");
                        List<Car> list = query.list();
                        list.forEach(car -> System.out.println(car));
                        long count = list.stream().mapToInt(p -> p.getId()).count();
                        double sum = list.stream().mapToDouble(p -> p.getSalesPrice()).sum();
                        NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.US);
                        System.out.println();
                        System.out.println("Number of Cars : " + count);
                        System.out.println("Total Inventory :          " + formatter.format(sum));
                        System.out.println();
                        System.out.println("What do you want to next ?  : ");
                        System.out.print("Enter Your Choice : ");
                        choice = sc.nextInt();
                        break;
                    case 3:
                        System.out.println("Delete The Car Deatils By Entering the id : ");
                        int id = sc.nextInt();
                        Car deleteCar = session.get(Car.class, id);
                        session.delete(deleteCar);
                        t.commit();
                        System.out.println("Car Details Deleted SuccessFully");
                        System.out.println();
                        System.out.println("What do you want to next ?  : ");
                        System.out.print("Enter Your Choice : ");
                        choice = sc.nextInt();
                        break;
                    case 4:
                        System.out.println("Update Car Details By Entering id : ");
                        int id2 = sc.nextInt();
                        Car updateCar = session.get(Car.class, id2);
                        System.out.print("Enter the new salesprice : ");
                        updateCar.setSalesPrice(sc.nextFloat());
                        session.update(updateCar);
                        t.commit();
                        System.out.println("Car Details Updated SuccessFully");
                        System.out.println();
                        System.out.println("What do you want to next ?  : ");
                        System.out.print("Enter Your Choice : ");
                        choice = sc.nextInt();
                        break;
                    case 5:
                        break;
                    default:
                        System.out.println("Please enter the right choice");
                        choice = sc.nextInt();
                        break;
                }
            }
            session.close();
        } catch (HibernateException e) {
            e.printStackTrace();
        }
        System.out.println();
        System.out.println(" Thank You Clsoing The Application ");
    }
}
