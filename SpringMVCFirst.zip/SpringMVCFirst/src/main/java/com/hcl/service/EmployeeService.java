package com.hcl.service;

import java.util.List;

import com.hcl.DTO.EmployeeDTO;
import com.hcl.model.Employee;

public interface EmployeeService {

	void saveEmployee(EmployeeDTO employeeDTO);

	List<Employee> getEmployee();

	void deleteEmployee(int employeeId);

	void updateEmployee(EmployeeDTO employeeDTO);

	EmployeeDTO getEmployeeById(int employeeId);

}
