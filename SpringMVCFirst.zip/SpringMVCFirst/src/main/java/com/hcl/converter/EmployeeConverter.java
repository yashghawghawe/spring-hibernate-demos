package com.hcl.converter;

import org.springframework.stereotype.Component;

import com.hcl.DTO.EmployeeDTO;
import com.hcl.model.Employee;

@Component
public class EmployeeConverter {
	
	public Employee convertDTOToEmployee(EmployeeDTO dto){
		Employee employee = new Employee();
		employee.setEmployeeId(dto.getEmployeeId());
		employee.setName(dto.getName());
		employee.setEmail(dto.getEmail());
		employee.setContact(dto.getContact());
		return employee;
		
	}
	
	public EmployeeDTO convertEmployeeToDTO(Employee employee){
		EmployeeDTO employeeDTO = new EmployeeDTO();
		employeeDTO.setEmployeeId(employee.getEmployeeId());
		employeeDTO.setName(employee.getName());
		employeeDTO.setEmail(employee.getEmail());
		employeeDTO.setContact(employee.getContact());
		return employeeDTO;
		
	}

}
