package com.hcl.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Employee {
	
	private int employeeId;
	private String name;
	private String email;
	private String contact;

}
