package com.hcl.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeDTO {
	
	private int employeeId;
	private String name;
	private String email;
	private String contact;

}
