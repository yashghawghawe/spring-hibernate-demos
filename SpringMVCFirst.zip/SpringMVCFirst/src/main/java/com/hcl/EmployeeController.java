package com.hcl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.DTO.EmployeeDTO;
import com.hcl.model.Employee;
import com.hcl.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@RequestMapping(value = "/showRegForm", method = RequestMethod.GET)
	public ModelAndView registerEmployee() {
		Employee employee = new Employee();
		ModelAndView modelAndView = new ModelAndView("register");
		modelAndView.addObject(employee);
		return modelAndView;
	}

	@RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute("employee") EmployeeDTO employeeDTO) {
		ModelAndView modelAndView = null;
		if (employeeDTO != null) {
			service.saveEmployee(employeeDTO);
			modelAndView = new ModelAndView("redirect:/getEmployee");
		}
		return modelAndView;

	}

	@RequestMapping(value = "/getEmployee", method = RequestMethod.GET)
	public ModelAndView getEmployee() {
		ModelAndView modelAndView = new ModelAndView("employeeList");
		List<Employee> employees = service.getEmployee();
		modelAndView.addObject("empList", employees);
		return modelAndView;
	}

	@RequestMapping(value = "/deleteEmp/{employeeId}")
	public ModelAndView deleteEmployee(@PathVariable("employeeId") int employeeId) {
		ModelAndView modelAndView = new ModelAndView("redirect:/getEmployee");
		service.deleteEmployee(employeeId);
		return modelAndView;
	}

	@RequestMapping(value = "/edit/{employeeId}")
	public ModelAndView editPerson(@PathVariable("employeeId") int employeeId, ModelAndView modelAndView) {
		modelAndView.addObject("employee", service.getEmployeeById(employeeId));
		modelAndView.setViewName("register");
		return modelAndView;

	}

	@RequestMapping(value = "edit/saveEmployee", method = RequestMethod.POST)
	public ModelAndView updateEmployee(@ModelAttribute("employee") EmployeeDTO employeeDTO, ModelAndView modelAndView) {
		service.updateEmployee(employeeDTO);
		modelAndView.setViewName("redirect:/getEmployee");
		return modelAndView;

	}

}
