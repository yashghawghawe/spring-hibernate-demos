package com.hcl.DAOImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.hcl.DAO.EmployeeDAO;
import com.hcl.model.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	List<Employee> employees = new ArrayList<Employee>();

	public void saveEmployee(Employee employee) {
		employees.add(employee);
		System.out.println(employees.toString());

	}

	public List<Employee> getEmployee() {
		return employees;

	}

	public void deleteEmployee(int employeeId) {
		employees.remove(employeeId);
		System.out.println(employees.toString());
	}

	public void updateEmployee(Employee employee) {
		Employee employee2 = getEmployeeById(employee.getEmployeeId());
		if (employee2 != null) {
			employees.set(employee.getEmployeeId(), employee);
		}
		System.out.println(employees);

	}
	
	public Employee getEmployeeById(int employeeId){
		Employee employee = employees.get(employeeId);
		return employee;
	}

}
