package com.hcl.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.EmployeeController;
import com.hcl.DAO.EmployeeDAO;
import com.hcl.DAOImpl.EmployeeDAOImpl;
import com.hcl.DTO.EmployeeDTO;
import com.hcl.converter.EmployeeConverter;
import com.hcl.model.Employee;
import com.hcl.service.EmployeeService;

/**
 * @author yash.ghawghawe Its a springMVC example using spring @version 4.3.14
 * 
 *         <h1>EmployeeServiceImpl</h1> The purpose of this class is to implement
 *         business logic and act as a intermediary layer between controller and
 *         DAO layers Please refer {@link EmployeeController} and
 *         {@link EmployeeDAOImpl}
 */

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;
	private int count = 0;

	@Autowired
	private EmployeeConverter converter;

	/**
	 * method for saving the employee object
	 * 
	 * @param employeeDTO
	 * @return nothing
	 */
	
	/* (non-Javadoc)
	 * @see com.hcl.service.EmployeeService#saveEmployee(com.hcl.DTO.EmployeeDTO)
	 */
	public void saveEmployee(EmployeeDTO employeeDTO) {
		employeeDTO.setEmployeeId(count++);
		Employee employee = converter.convertDTOToEmployee(employeeDTO);
		//System.out.println(employee);
		employeeDAO.saveEmployee(employee);

	}

	/**
	 * method for fetching the List of employees
	 * 
	 * @return List<Employee>
	 */

	public List<Employee> getEmployee() {
		List<Employee> employees = employeeDAO.getEmployee();
		return employees;
	}

	/**
	 * method for deleting the specified employee
	 * 
	 * @param employeeId
	 * @return nothing
	 */

	public void deleteEmployee(int employeeId) {
		employeeDAO.deleteEmployee(employeeId);

	}

	/**
	 * method for updating the specified employee
	 * 
	 * @param employeeDTO
	 * @return nothing
	 */

	public void updateEmployee(EmployeeDTO employeeDTO) {
		Employee employee = converter.convertDTOToEmployee(employeeDTO);
		employeeDAO.updateEmployee(employee);

	}

	/**
	 * method for fetching the specified employee
	 * 
	 * @param employeeId
	 * @return EmployeeDTO
	 */

	public EmployeeDTO getEmployeeById(int employeeId) {
		Employee employee = employeeDAO.getEmployeeById(employeeId);
		EmployeeDTO dto = converter.convertEmployeeToDTO(employee);
		return dto;
	}

}
