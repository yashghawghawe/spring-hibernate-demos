package com.hcl.DAO;

import java.util.List;

import com.hcl.model.Employee;

public interface EmployeeDAO {

	void saveEmployee(Employee employee);

	List<Employee> getEmployee();

	void deleteEmployee(int employeeId);

	void updateEmployee(Employee employee);

	Employee getEmployeeById(int employeeId);

}
