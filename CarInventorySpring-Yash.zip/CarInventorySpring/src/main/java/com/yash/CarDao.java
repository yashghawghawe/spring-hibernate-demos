/**
 * 
 */
package com.yash;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * @author yash.ghawghawe
 *
 */
public class CarDao {

    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int saveCar(Car car) {
        String insertQuery = "insert into car(make,model,year,salesPrice) values('" + car.getMake() + "','"
                + car.getModel() + "','" + car.getYear()
                + "','" + car.getSalesPrice() + "') ";
        return jdbcTemplate.update(insertQuery);
    }

    public List<Car> getAll() {
        String sql = "select * from car";
        List<Car> employee = jdbcTemplate.query(sql,new CarRowMapper());
        return employee;
    }

    public int deleteCar(int id) {
        String deleteQuery = "delete from car where id='" + id + "'";
        return jdbcTemplate.update(deleteQuery);
    }

    public int updateCar(Object updateDetail, int id) {
        String updateQuery = "update car set model = '" + updateDetail + "' where id='" + id + "'";
        return jdbcTemplate.update(updateQuery);

    }

}
