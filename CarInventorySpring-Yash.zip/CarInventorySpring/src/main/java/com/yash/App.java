package com.yash;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author yash.ghawghawe
 *
 */
public class App {

    static Scanner sc = new Scanner(System.in);
    static String choice = "";
    static Car car = new Car();

    public static void main(String[] args) {
        System.out.println("*******Welcome to Yash Automobiles**********");
        System.out.println();
        System.out.println("Select From The Below Menu");
        System.out.println("Enter add -> To Add Car Details");
        System.out.println("Enter list -> To get all Car Details");
        System.out.println("Enter delete -> to Delete Car Details");
        System.out.println("Enter update -> To Update Car Details");
        System.out.println("Enter exit -> to exit the application");
        solution();
        System.out.println();
        System.out.println(" Thank You Clsoing The Application ");

    }

    private static void solution() {
        System.out.print("Enter Your Choice : ");
        choice = sc.next();
        if (choice.equalsIgnoreCase("exit")) {
            System.out.println("See yaa!!");
        } else {
            ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
            CarDao carDao = context.getBean("cardao", CarDao.class);
            while (!choice.equalsIgnoreCase("exit")) {
                switch (choice.toLowerCase()) {
                    case "add":
                        System.out.println("Enter The Car Details");
                        System.out.print("make : ");
                        car.setMake(sc.next());
                        System.out.println();
                        System.out.print("model : ");
                        car.setModel(sc.next());
                        System.out.println();
                        System.out.print("year : ");
                        car.setYear(Integer.parseInt(sc.next()));
                        System.out.println();
                        System.out.print("sales price ($) : ");
                        car.setSalesPrice(Float.parseFloat(sc.next()));
                        int result = carDao.saveCar(car);
                        if (result > 0) {
                            System.out.println("Details SuccessFully Saved!");
                            System.out.println();
                            System.out.println("What do you want to do next ?\nadd\ndelete\nupdate\nexit ");
                            System.out.print("Enter Your Choice : ");
                            choice = sc.next();
                        }
                        break;
                    case "list":
                        List<Car> cars = carDao.getAll();
                        if (cars.size() == 0) {
                            System.out.println("Catalog is Empty");
                        } else {
                            cars.forEach(car -> System.out.println(car));
                            long count = cars.stream().mapToInt(p -> p.getId()).count();
                            double sum = cars.stream().mapToDouble(p -> p.getSalesPrice()).sum();
                            NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.US);
                            System.out.println();
                            System.out.println("Number of Cars : " + count);
                            System.out.println("Total Inventory :          " + formatter.format(sum));
                            System.out.println();
                            System.out.println("What do you want to do next ?\nadd\nlist\ndelete\nupdate\nexit ");
                            System.out.print("Enter Your Choice : ");
                            choice = sc.next();
                        }
                        break;
                    case "delete":
                        System.out.println("Delete The Car Details By Entering the id : ");
                        int id = sc.nextInt();
                        int delete = carDao.deleteCar(id);
                        if (delete > 0) {
                            System.out.println("Car Details Deleted SuccessFully");
                            System.out.println();
                            System.out.println("What do you want to do next ?\nadd\ndelete\nupdate\nexit ");
                            System.out.print("Enter Your Choice : ");
                            choice = sc.next();
                        }
                        break;
                    case "update":
                        System.out.println("Update Car Details By Entering id : ");
                        int id2 = sc.nextInt();
                        int update = 0;
                        System.out.println("Enter which details you want to update");
                        System.out.println("Make :");
                        System.out.println("Model :");
                        System.out.println("Year :");
                        System.out.println("Sale Price ");
                        System.out.println("--------------------------------------------");
                        String updateDetails = sc.next();
                        if (updateDetails.equalsIgnoreCase("Model")) {
                            System.out.print("Enter Model : ");
                            update = carDao.updateCar(sc.next(), id2);
                        } else if (updateDetails.equalsIgnoreCase("salesprice")) {
                            System.out.print("Enter the new salesprice : ");
                            update = carDao.updateCar(sc.nextFloat(), id2);
                        } else if (updateDetails.equalsIgnoreCase("year")) {
                            System.out.print("Enter Year : ");
                            update = carDao.updateCar(sc.nextInt(), id2);
                        } else {
                            System.out.println(updateDetails + " is not a valid command. Please try again");
                        }
                        if (update > 0) {
                            System.out.println("Car Details Updated SuccessFully");
                            System.out.println();
                            System.out.println("What do you want to do next ?\nadd\ndelete\nupdate\nexit ");
                            System.out.print("Enter Your Choice : ");
                            choice = sc.next();
                        }
                        break;
                    case "exit":
                        break;
                    default:
                        System.out.println("Please enter the right choice");
                        choice = sc.next();
                        break;
                }
            }
            context.close();
        }
    }
}
