package com.yash;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CarRowMapper implements RowMapper<Car>{

    @Override
    public Car mapRow(ResultSet rs, int arg1) throws SQLException {
        Car car = new Car();
        car.setId(rs.getInt(1));
        car.setMake(rs.getString(2));
        car.setModel(rs.getString(3));
        car.setYear(rs.getInt(4));
        car.setSalesPrice(rs.getFloat(5));
        return car;
    }

}
