package com.yash;

import java.text.NumberFormat;
import java.util.Locale;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Car {

    private int id;
    private String make;
    private String model;
    private int year;
    private float salesPrice;

    @Override
    public String toString() {
        NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.US);
        return make + " " + model + " " + year + "          " + formatter.format(salesPrice);
    }

}
