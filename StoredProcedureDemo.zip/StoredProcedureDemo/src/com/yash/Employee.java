package com.yash;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedNativeQueries;
import org.hibernate.annotations.NamedNativeQuery;

@Entity
@Table
@NamedNativeQueries({
    @NamedNativeQuery(
        name ="getEmployees",
        query="call getEmployees()",
        resultClass = Employee.class
    )
})
public class Employee {
    
    @Id
    @Column(name ="id")
    private int empid;
    private int age;
    private String firstName, lastName, email;

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Employee [empid=" + empid + ", age=" + age + ", firstName=" + firstName + ", lastName=" + lastName
                + ", email=" + email + "]";
    }

}
