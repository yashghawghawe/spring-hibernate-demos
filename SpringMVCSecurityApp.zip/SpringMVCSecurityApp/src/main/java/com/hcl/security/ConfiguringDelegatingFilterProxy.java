package com.hcl.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/**
 * @author yash.ghawghawe
 *
 */
public class ConfiguringDelegatingFilterProxy extends AbstractSecurityWebApplicationInitializer{
    
    public ConfiguringDelegatingFilterProxy(){
        super(LoginSecurityConfig.class);
    }

}
