package com.hcl.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author yash.ghawghawe
 *
 */

@RestController
public class LoginController {

    @RequestMapping("/")
    public ModelAndView showWelcomePage() {
        return new ModelAndView("welcome");
    }

    @RequestMapping("/admin")
    public ModelAndView showAdminPage() {
        return new ModelAndView("admin");
    }

    @RequestMapping("/success")
    public ModelAndView showSuccessPage() {
        return new ModelAndView("success");
    }

    @RequestMapping("/403")
    public ModelAndView showAccesssDeniedPage() {
        return new ModelAndView("access_denied", "msg", "You dont have permission to access this page!");
    }

    @RequestMapping("/login")
    public ModelAndView showLoginPage(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout) {
        if (error != null) {
            return new ModelAndView("login", "error", "Invalid login Credentials");
        } else if (logout != null) {
            return new ModelAndView("login", "message", "Logged Out Successfully");
        }
        return new ModelAndView("login");
    }

}
