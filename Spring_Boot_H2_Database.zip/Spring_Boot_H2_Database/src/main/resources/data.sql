insert into employee values(101,'Yash');
insert into employee values(102,'Rahul');

insert into department values(1,'Apps & SI');
insert into department values(2,'Infra');