package com.yash.repository;

import org.springframework.data.repository.CrudRepository;

import com.yash.model.User;

public interface UserRepositroy extends CrudRepository<User,Integer>{

}
