package com.yash.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class department {
	@Id
	private int id;
	private String deptname;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
}
