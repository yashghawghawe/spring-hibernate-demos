package com.yash.service;

import java.util.List;
import java.util.Optional;

import com.yash.model.User;

public interface UserService {
	User createUser(User user);

	List<User> readAll();

	User updateUser(User user);

	public void deleteUser(int Userid);

    Optional<User> findByid(int id);


}
