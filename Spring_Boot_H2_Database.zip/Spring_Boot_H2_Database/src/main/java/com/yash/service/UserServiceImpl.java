package com.yash.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dao.UserDao;
import com.yash.model.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {

   @Autowired
   private UserDao userDao;

    @Override
    public User createUser(User user) {
        User result = this.userDao.save(user);
        return result;

    }

    public List<User> readAll() {

        List<User> listAll = (List<User>) userDao.findAll();
        return listAll;
    }

    @Override
    public User updateUser(User user) {
        return this.userDao.update(user);
    }

    @Override
    public void deleteUser(int Userid) {
        Optional<User> option = this.userDao.findById(Userid);
        User user = null;
        if (option.isPresent()) {
            user = option.get();
            userDao.delete(user);
        }

    }

    @Override
    public Optional<User> findByid(int id) {

        return userDao.findById(id);
    }
}
