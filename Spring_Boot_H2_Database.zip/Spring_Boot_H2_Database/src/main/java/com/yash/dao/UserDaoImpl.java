package com.yash.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.model.User;
import com.yash.repository.UserRepositroy;

@Repository
public class UserDaoImpl implements UserDao{
    
    @Autowired
    private UserRepositroy userRepositroy;

    @Override
    public User save(User user) {
        return userRepositroy.save(user);
    }

    @Override
    public Iterable<User> findAll() {
        Iterable<User> user= userRepositroy.findAll();
        return user;
    }

    @Override
    public Optional<User> findById(int userid) {
        Optional<User> user = userRepositroy.findById(userid);
        return user;
    }

    @Override
    public User update(User user) {
        return userRepositroy.save(user);
    }

    @Override
    public void delete(User user) {
        userRepositroy.delete(user);
    }

}
