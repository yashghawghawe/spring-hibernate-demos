package com.yash.dao;

import java.util.List;
import java.util.Optional;

import com.yash.model.User;

public interface UserDao {

    User save(User user);

    Iterable<User> findAll();

    Optional<User> findById(int userid);

    User update(User user);

    void delete(User user);

}
