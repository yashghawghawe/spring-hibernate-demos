package com.hcl.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dao.LoginDao;
import com.hcl.model.Login;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginDao loginDao;

    public void saveData(Login login) {
        loginDao.saveData(login);
    }

    public List<Login> getAll() {
        List<Login> list = loginDao.getAll();
        return list;
    }

    public Login fetchById(int id) {
        Login login = loginDao.fetchById(id);
        return login;
    }

}
