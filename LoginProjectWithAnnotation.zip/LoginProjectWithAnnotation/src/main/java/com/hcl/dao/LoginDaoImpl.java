package com.hcl.dao;

import java.util.Base64;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Login;

@Repository
public class LoginDaoImpl implements LoginDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void saveData(Login login) {
        sessionFactory.openSession().save(login);
        System.out.println("save");
    }

    @SuppressWarnings("unchecked")
    public List<Login> getAll() {
        Query query = sessionFactory.getCurrentSession().createQuery("from Login");
        List<Login> list = query.list();
//        for (Login login : list) {
//            String encoded = login.getPassword();
//            byte[] decodedBytes = Base64.getDecoder().decode(encoded);
//            String decoded = new String(decodedBytes);
//            login.setPassword(decoded);
//        }
        return list;
    }

    public Login fetchById(int id) {
        Login login = (Login) sessionFactory.getCurrentSession()
                .createSQLQuery("select * from loginUsers where id = '" + id + "'").addEntity(Login.class).uniqueResult();
        return login;
    }
}
