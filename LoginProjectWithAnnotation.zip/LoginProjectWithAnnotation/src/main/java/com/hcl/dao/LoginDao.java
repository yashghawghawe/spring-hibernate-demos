package com.hcl.dao;

import java.util.List;

import com.hcl.model.Login;

public interface LoginDao {

    void saveData(Login login);

    List<Login> getAll();

    Login fetchById(int id);

}
