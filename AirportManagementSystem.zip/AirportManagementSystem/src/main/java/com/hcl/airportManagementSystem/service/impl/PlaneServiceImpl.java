package com.hcl.airportManagementSystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.airportManagementSystem.dao.PlaneDao;
import com.hcl.airportManagementSystem.model.Plane;
import com.hcl.airportManagementSystem.service.PlaneService;

@Service
@Transactional
public class PlaneServiceImpl implements PlaneService {

	@Autowired
	PlaneDao planedao;

	@Override
	public int addPlane(Plane plane) {
		Plane plane2 = this.planedao.save(plane);
		return plane2.getPlaneId();
	}

	@Override
	public List<Plane> getPlaneList() {
		return this.planedao.getPlaneList();
	}

	@Override
	public Plane getPlanebyPlaneId(int planeId) {
		return this.planedao.getOne(planeId);
	}

	@Override
	public void updatePlane(Plane plane) {
		Plane entity = this.planedao.getOne(plane.getPlaneId());
		if (entity != null) {
			entity.setOwnerFirstName(plane.getOwnerFirstName());
			entity.setOwnerLastName(plane.getOwnerLastName());
			entity.setOwnerConactNo(plane.getOwnerConactNo());
			entity.setOwnerEmail(plane.getOwnerEmail());
			entity.setPlaneType(plane.getPlaneType());
			entity.setPlaneCapasity(plane.getPlaneCapasity());
		}
	}

}
