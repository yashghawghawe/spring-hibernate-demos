package com.hcl.airportManagementSystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.airportManagementSystem.dao.HangerStatusDao;
import com.hcl.airportManagementSystem.model.HangerStatus;
import com.hcl.airportManagementSystem.service.HangerStatusService;

@Service
@Transactional
public class HangerStatusServiceImpl implements HangerStatusService {

	@Autowired
	HangerStatusDao hangerstatusdao;

	@Override
	public int addHangerstatus(HangerStatus hangerStatus) {
		HangerStatus h = this.hangerstatusdao.save(hangerStatus);
		return h.getHangerId();
	}

	@Override
	public List<HangerStatus> getHangerStatusList() {
		return this.hangerstatusdao.getHangerStatusList();
	}

	@Override
	public HangerStatus getHangerStatusBuId(int hangerId) {
		return this.hangerstatusdao.getOne(hangerId);
	}

	@Override
	public void updateHangerStatus(HangerStatus hangerStatus) {
		HangerStatus entity = this.hangerstatusdao.getOne(hangerStatus.getHangerStatusId());
		if (entity != null) {
			entity.setManagerId(hangerStatus.getManagerId());
			entity.setStatus(hangerStatus.getStatus());
			entity.setOccupiedFrom(hangerStatus.getOccupiedFrom());
			entity.setOccupiedTill(hangerStatus.getOccupiedTill());
			entity.setAvailableFrom(hangerStatus.getAvailableFrom());
			entity.setAvailableTill(hangerStatus.getAvailableTill());
		}
	}

}
