package com.hcl.airportManagementSystem.service;

import java.util.List;

import com.hcl.airportManagementSystem.model.HangerStatus;

public interface HangerStatusService {

	int addHangerstatus(HangerStatus hangerStatus);

	List<HangerStatus> getHangerStatusList();

	HangerStatus getHangerStatusBuId(int hangerId);

	void updateHangerStatus(HangerStatus hangerStatus);
}
