package com.hcl.airportManagementSystem.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.airportManagementSystem.model.Plane;
import com.hcl.airportManagementSystem.service.PlaneService;

@Controller
@RequestMapping("/plane")
public class PlaneController {

	@Autowired
	PlaneService planeservice;

	@GetMapping("/addPlane")
	String showAddPlane(HttpServletRequest request, ModelMap map) {
		map.addAttribute("plane", new Plane());
		return "plane/addPlane";
	}

	@PostMapping("/addPlane")
	String addPlane(@ModelAttribute("plane") Plane plane, HttpServletRequest request, ModelMap map) {
		planeservice.addPlane(plane);
		return "redirect:../plane/listPlane?msg=Plane added successfully";
	}

	@RequestMapping("/listPlane")
	String showPlaneList(HttpServletRequest request, ModelMap map) {
		map.addAttribute("planeList", planeservice.getPlaneList());
		return "plane/listPlane";
	}

	@GetMapping("/editPlane")
	String showEditPlane(HttpServletRequest request, ModelMap map) {
		int planeId = ServletRequestUtils.getIntParameter(request, "planeId", 0);
		map.addAttribute("plane", planeservice.getPlanebyPlaneId(planeId));
		return "plane/editPlane";
	}

	@PostMapping("/editPlane")
	String updatePlane(@ModelAttribute("plane") Plane plane, HttpServletRequest request, ModelMap map) {
		planeservice.updatePlane(plane);
		return "redirect:../plane/listPlane?msg=Plane updated successfully";
	}

}
