package com.hcl.airportManagementSystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.airportManagementSystem.dao.PilotDao;
import com.hcl.airportManagementSystem.model.Pilots;
import com.hcl.airportManagementSystem.service.PilotService;

@Service
@Transactional
public class PilotsServiceImpl implements PilotService {

	@Autowired
	PilotDao pilotdao;

	@Override
	public int addPilot(Pilots pilot) {
		Pilots p = this.pilotdao.save(pilot);
		return p.getPilotId();
	}

	@Override
	public List<Pilots> getPilotList() {
		return this.pilotdao.getPilotList();
	}

	@Override
	public Pilots getPolitbyPilotId(int pilotId) {
		return this.pilotdao.getOne(pilotId);
	}

	@Override
	public void updatePilot(Pilots pilot) {
		Pilots entity = this.pilotdao.getOne(pilot.getPilotId());
		if (entity != null) {
			entity.setLicenseNo(pilot.getLicenseNo());
			entity.setAddreesLine1(pilot.getAddreesLine1());
			entity.setAddreesLine2(pilot.getAddreesLine2());
			entity.setCity(pilot.getCity());
			entity.setState(pilot.getState());
			entity.setZip(pilot.getZip());
		}

	}

}
