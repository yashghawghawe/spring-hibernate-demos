package com.hcl.airportManagementSystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hcl.airportManagementSystem.model.Pilots;

@Repository
public interface PilotDao extends JpaRepository<Pilots, Integer> {

	@Query("FROM Pilots p")
	public List<Pilots> getPilotList();
}
