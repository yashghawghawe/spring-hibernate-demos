package com.hcl.airportManagementSystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hcl.airportManagementSystem.model.HangerStatus;

@Repository
public interface HangerStatusDao extends JpaRepository<HangerStatus, Integer> {

	@Query("FROM HangerStatus h")
	public List<HangerStatus> getHangerStatusList();
}
