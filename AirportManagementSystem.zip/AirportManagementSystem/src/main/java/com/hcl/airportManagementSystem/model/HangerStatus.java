package com.hcl.airportManagementSystem.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class HangerStatus {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private int hangerStatusId;
	private int hangerId;
	private int managerId;
	private char status;//A/O
	private Date occupiedFrom;
	private Date occupiedTill;
	private Date AvailableFrom;
	private Date AvailableTill;
}
