package com.hcl.airportManagementSystem.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.airportManagementSystem.model.Pilots;
import com.hcl.airportManagementSystem.service.PilotService;

@Controller
@RequestMapping("/pilot")
public class PilotController {
	@Autowired
	PilotService pilotservice;

	@GetMapping("/addPilot")
	String showAddPilot(HttpServletRequest request, ModelMap map) {
		map.addAttribute("pilot", new Pilots());
		return "pilot/addPilot";
	}

	@PostMapping("/addPilot")
	String addPilot(@ModelAttribute("pilot") Pilots pilot, HttpServletRequest request, ModelMap map) {
		pilotservice.addPilot(pilot);
		return "redirect:../pilot/listPilot?msg=Pilot added successfully";
	}

	@RequestMapping("/listPilot")
	String showPilotList(HttpServletRequest request, ModelMap map) {
		map.addAttribute("pilotList", pilotservice.getPilotList());
		return "pilot/listPilot";
	}

	@GetMapping("/editPilot")
	String showEditPilot(HttpServletRequest request, ModelMap map) {
		int pilotId = ServletRequestUtils.getIntParameter(request, "pilotId", 0);
		map.addAttribute("pilot", pilotservice.getPolitbyPilotId(pilotId));
		return "pilot/editPilot";
	}

	@PostMapping("/editPilot")
	String updatePilot(@ModelAttribute("pilot") Pilots pilot, HttpServletRequest request, ModelMap map) {
		pilotservice.updatePilot(pilot);
		return "redirect:../pilot/listPilot?msg=Pilot updated successfully";
	}
}
