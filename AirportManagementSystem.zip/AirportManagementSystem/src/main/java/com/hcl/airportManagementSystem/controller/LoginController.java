package com.hcl.airportManagementSystem.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.airportManagementSystem.model.User;
import com.hcl.airportManagementSystem.securityConfig.CustomUserDetails;
import com.hcl.airportManagementSystem.service.UserService;

@Controller
public class LoginController {

	@Autowired
	UserService userService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@RequestMapping(value = "/home/login", method = RequestMethod.GET)
	public String showRegister(HttpServletRequest request, ModelMap model) {

		model.addAttribute("msg", ServletRequestUtils.getStringParameter(request, "msg", ""));
		return "home/login";
	}

	@RequestMapping(value = "/home/index")
	public String indexPage(HttpServletRequest request, ModelMap map) {
		char role = ((CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
				.getUser().getUserRole();
		List<User> userList = this.userService.getUserList();
		map.addAttribute("userList", role == 'A' ? userList : null);
		return "home/index";
	}

	@RequestMapping(value = "/home/success", method = RequestMethod.GET)
	public String showSuccess(HttpServletRequest request, ModelMap model) {
		return "home/sucess";
	}

	@RequestMapping(value = "/home/signup", method = RequestMethod.GET)
	public String showSignup(HttpServletRequest request, ModelMap model) {
		model.addAttribute("registration", new User());
		return "home/registration";
	}

	@RequestMapping(value = "/home/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("registration") User user, HttpServletRequest request, ModelMap model) {
		userService.saveUser(user);
		return "redirect:../home/login?msg=Registration Successful";
	}

}
