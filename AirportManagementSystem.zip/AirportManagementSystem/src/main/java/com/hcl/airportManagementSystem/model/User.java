package com.hcl.airportManagementSystem.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userId;
	private String firstName;
	private String lastName;
	private int age;
	private String gender;
	private Date dob;
	private String contactNo;
	private String altContactNo;
	private String email;
	private String password;
	
	@Column(name = "user_role", updatable = false, columnDefinition = "CHAR(1) NOT NULL COMMENT 'A = Admin,M = Manager'")
	private char userRole;
	
	@Column(name = "user_status", updatable = true, columnDefinition = "CHAR(1) NOT NULL COMMENT 'N = New,A = Active,D = De-Active'")
	private char userStatus;
}
