package com.hcl.airportManagementSystem.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hcl.airportManagementSystem.model.Plane;

@Repository
public interface PlaneDao extends JpaRepository<Plane, Integer> {

	@Query("FROM Plane p")
	public List<Plane> getPlaneList();
}
