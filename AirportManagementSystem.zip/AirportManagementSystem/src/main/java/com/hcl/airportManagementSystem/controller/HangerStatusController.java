package com.hcl.airportManagementSystem.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.airportManagementSystem.model.HangerStatus;
import com.hcl.airportManagementSystem.service.HangerService;
import com.hcl.airportManagementSystem.service.HangerStatusService;
import com.hcl.airportManagementSystem.service.UserService;

@Controller
@RequestMapping("/hangerStatus")
public class HangerStatusController {

	@Autowired
	HangerStatusService hangerStatusservice;

	@Autowired
	UserService userservice;
	
	@Autowired
	HangerService hangerservice;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	@GetMapping("/allotHanger")
	String showAddHanger(HttpServletRequest request, ModelMap map) {
		map.addAttribute("hangerStatus", new HangerStatus());
		map.addAttribute("managerList", this.userservice.getUserList());
		map.addAttribute("hangerList", this.hangerservice.getHangerList());
		return "hangerStatus/addHangerStatus";
	}

	@PostMapping("/allotHanger")
	String addHanger(@ModelAttribute("hangerStatus") HangerStatus hangerStatus, HttpServletRequest request,
			ModelMap map) {
		hangerStatusservice.addHangerstatus(hangerStatus);
		return "redirect:../hangerStatus/listHangerStatus?msg=Hanger added successfully";
	}

	@RequestMapping("/listHangerStatus")
	String showHangerList(HttpServletRequest request, ModelMap map) {
		map.addAttribute("hangerStatusList", hangerStatusservice.getHangerStatusList());
		return "hangerStatus/listHangerStatus";
	}

	@GetMapping("/editHangerStatus")
	String showEditHanger(HttpServletRequest request, ModelMap map) {
		int hangerStatusId = ServletRequestUtils.getIntParameter(request, "hangerStatusId", 0);
		map.addAttribute("hangerStatus", hangerStatusservice.getHangerStatusBuId(hangerStatusId));
		map.addAttribute("managerList", this.userservice.getUserList());
		map.addAttribute("hangerList", this.hangerservice.getHangerList());
		return "hangerStatus/editHangerStatus";
	}

	@PostMapping("/editHangerStatus")
	String updateHanger(@ModelAttribute("hangerStatus") HangerStatus hangerStatus, HttpServletRequest request,
			ModelMap map) {
		hangerStatusservice.updateHangerStatus(hangerStatus);
		return "redirect:../hangerStatus/listHangerStatus?msg=Hanger updated successfully";
	}
}
