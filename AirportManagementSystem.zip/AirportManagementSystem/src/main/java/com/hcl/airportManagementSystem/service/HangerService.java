package com.hcl.airportManagementSystem.service;

import java.util.List;

import com.hcl.airportManagementSystem.model.Hanger;

public interface HangerService {

	int saveHanger(Hanger hanger);

	List<Hanger> getHangerList();

	Hanger getHangerByHangerId(int hangerid);

	void updateHanger(Hanger hanger);

}
