package com.hcl.airportManagementSystem.service;

import java.util.List;

import com.hcl.airportManagementSystem.model.Pilots;

public interface PilotService {

	int addPilot(Pilots pilot);

	List<Pilots> getPilotList();

	Pilots getPolitbyPilotId(int pilotId);

	void updatePilot(Pilots pilot);
}
