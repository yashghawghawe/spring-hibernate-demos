package com.hcl.airportManagementSystem.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hcl.airportManagementSystem.dao.UserDao;
import com.hcl.airportManagementSystem.model.User;
import com.hcl.airportManagementSystem.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Override
	public int saveUser(User user) {
		PasswordEncoder encoder = new BCryptPasswordEncoder();
		user.setPassword(encoder.encode(user.getPassword()));
		user = this.userDao.save(user);
		return user.getUserId();
	}

	@Override
	public User getUserByUserId(int userId) {
		Optional<User> u = this.userDao.findById(userId);
		if (u.isPresent()) {
			return u.get();
		} else {
			return null;
		}
	}

	@Override
	public User getUserByUserName(String userName) {
		return this.userDao.getUserByUsername(userName);
	}

	@Override
	public void updateCustomerUserStatus(int userId, char userStatus) {
		this.userDao.updateCustomerUserStatus(userId, userStatus);
	}

	@Override
	public List<User> getUserList() {
		return this.userDao.getAllUserList();
	}

}
