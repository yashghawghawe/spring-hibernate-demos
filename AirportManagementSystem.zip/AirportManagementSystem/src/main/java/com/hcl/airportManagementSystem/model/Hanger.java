package com.hcl.airportManagementSystem.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Hanger {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hangerId;
	private int managerId;
	private String managerAddreesLine1;
	private String managerAddreesLine2;
	private String city;
	private String state;
	private int zip;

	@Override
	public String toString() {
		return managerAddreesLine1 + ", " + managerAddreesLine2 + ", " + city + ", " + state + " - " + zip;
	}

}
