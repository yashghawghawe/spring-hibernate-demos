package com.hcl.airportManagementSystem.service;

import java.util.List;

import com.hcl.airportManagementSystem.model.User;

public interface UserService {

	int saveUser(User user);

	User getUserByUserName(String username);

	User getUserByUserId(int userId);

	void updateCustomerUserStatus(int userId, char userStatus);
	
	List<User> getUserList();
}
