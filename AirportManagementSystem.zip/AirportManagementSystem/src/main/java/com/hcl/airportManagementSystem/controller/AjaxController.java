package com.hcl.airportManagementSystem.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.airportManagementSystem.service.UserService;

@RestController
@RequestMapping("/ajax")
public class AjaxController {

	@Autowired
	UserService userService;

	@GetMapping("/updateUserStatus")
	public String updateUserStatus(HttpServletRequest request) {
		int userId = ServletRequestUtils.getIntParameter(request, "userId", 0);
		char userStatus = ServletRequestUtils.getStringParameter(request, "userStatus", "").charAt(0);
		this.userService.updateCustomerUserStatus(userId, userStatus);
		return "success";
	}

}
