package com.hcl.airportManagementSystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.airportManagementSystem.dao.Hangerdao;
import com.hcl.airportManagementSystem.model.Hanger;
import com.hcl.airportManagementSystem.service.HangerService;

@Service
@Transactional
public class HangerServiceImpl implements HangerService {
	@Autowired
	Hangerdao hangerdao;

	@Override
	public int saveHanger(Hanger hanger) {
		Hanger h = this.hangerdao.save(hanger);
		return h.getHangerId();
	}

	@Override
	public List<Hanger> getHangerList() {
		return this.hangerdao.getHangerList();
	}

	@Override
	public Hanger getHangerByHangerId(int hangerid) {
		return this.hangerdao.getOne(hangerid);
	}

	@Override
	public void updateHanger(Hanger hanger) {
		Hanger entity = this.hangerdao.getOne(hanger.getHangerId());
		if (entity != null) {
			entity.setManagerId(hanger.getManagerId());
			entity.setManagerAddreesLine1(hanger.getManagerAddreesLine1());
			entity.setManagerAddreesLine2(hanger.getManagerAddreesLine2());
			entity.setCity(hanger.getCity());
			entity.setState(hanger.getState());
			entity.setZip(hanger.getZip());
		}

	}

}
