package com.hcl.airportManagementSystem.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.airportManagementSystem.model.Hanger;
import com.hcl.airportManagementSystem.service.HangerService;
import com.hcl.airportManagementSystem.service.UserService;

@Controller
@RequestMapping("/hanger")
public class HangerController {
	@Autowired
	HangerService hangerservice;
	
	@Autowired
	UserService userService;

	@GetMapping("/addHanger")
	String showAddHanger(HttpServletRequest request, ModelMap map) {
		map.addAttribute("hanger", new Hanger());
		map.addAttribute("managerList",this.userService.getUserList());
		return "hanger/addHanger";
	}

	@PostMapping("/addHanger")
	String addHanger(@ModelAttribute("hanger") Hanger hanger, HttpServletRequest request, ModelMap map) {
		hangerservice.saveHanger(hanger);
		return "redirect:../hanger/listHanger?msg=Hanger added successfully";
	}

	@RequestMapping("/listHanger")
	String showHangerList(HttpServletRequest request, ModelMap map) {
		map.addAttribute("hangerList", hangerservice.getHangerList());
		return "hanger/listHanger";
	}

	@GetMapping("/editHanger")
	String showEditHanger(HttpServletRequest request, ModelMap map) {
		int hangerId = ServletRequestUtils.getIntParameter(request, "hangerId", 0);
		map.addAttribute("hanger", hangerservice.getHangerByHangerId(hangerId));
		map.addAttribute("managerList",this.userService.getUserList());
		return "hanger/editHanger";
	}

	@PostMapping("/editHanger")
	String updateHanger(@ModelAttribute("hanger") Hanger hanger, HttpServletRequest request, ModelMap map) {
		hangerservice.updateHanger(hanger);
		return "redirect:../hanger/listHanger?msg=Hanger updated successfully";
	}
}
