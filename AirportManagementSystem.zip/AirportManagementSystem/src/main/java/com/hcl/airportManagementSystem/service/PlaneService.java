package com.hcl.airportManagementSystem.service;

import java.util.List;

import com.hcl.airportManagementSystem.model.Plane;

public interface PlaneService {

	int addPlane(Plane plane);

	List<Plane> getPlaneList();

	Plane getPlanebyPlaneId(int planeId);

	void updatePlane(Plane plane);

}
