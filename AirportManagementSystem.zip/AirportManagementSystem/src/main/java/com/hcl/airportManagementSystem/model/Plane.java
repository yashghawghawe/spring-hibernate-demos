package com.hcl.airportManagementSystem.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Plane {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int planeId;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ownerId;

	private String ownerFirstName;
	private String ownerLastName;
	private String ownerConactNo;
	private String ownerEmail;
	private String planeType;
	private int planeCapasity;

}
