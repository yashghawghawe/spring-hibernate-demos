CREATE TABLE if not exists `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `age` int(11) NOT NULL,
  `alt_contact_no` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `dob` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_role` char(1) NOT NULL COMMENT 'A = Admin,M = Manager',
  `user_status` char(1) NOT NULL COMMENT 'N = New,A = Active,D = De-Active',
  PRIMARY KEY (`user_id`)
) ;