package com.hcl.service;

import java.util.List;

import com.hcl.model.Login;

public interface LoginService {

    public void saveData(Login login);

    public List<Login> getAll();

    public Login fetchById(int id);

}
