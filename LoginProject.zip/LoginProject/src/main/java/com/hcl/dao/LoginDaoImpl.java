package com.hcl.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.model.Login;

@Repository
public class LoginDaoImpl implements LoginDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void saveData(Login login) {
        sessionFactory.openSession().save(login);
        System.out.println("save");
    }

    @SuppressWarnings("unchecked")
    public List<Login> getAll() {
        Query<Login> query = sessionFactory.getCurrentSession().createQuery("from Login");
        List<Login> list = query.list();
        return list;
    }

    public Login fetchById(int id) {
        Login login = (Login) sessionFactory.getCurrentSession()
                .createSQLQuery("select * from login where id = '" + id + "'").addEntity(Login.class).uniqueResult();
        return login;
    }
}
