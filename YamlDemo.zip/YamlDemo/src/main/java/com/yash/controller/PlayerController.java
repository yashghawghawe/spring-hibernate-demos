/**
 * 
 */
package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.Player;
import com.yash.service.PlayerService;

/**
 * @author yash.ghawghawe
 *
 */
@RestController
public class PlayerController {
    
    @Autowired
    private PlayerService playerservice;
    
    @RequestMapping("/home")
    public String HomePage() {
        return "Welcome To Thaetre of dreams";
    }
    
    @RequestMapping(value = "/add", consumes = MediaType.APPLICATION_JSON_VALUE)
    public Player createEmployee(@RequestBody Player player) {
        Player p = playerservice.save(player);
        return p;
    }

}
