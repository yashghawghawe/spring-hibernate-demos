/**
 * 
 */
package com.yash.dao;

import com.yash.model.Player;

/**
 * @author yash.ghawghawe
 *
 */
public interface PlayerDao {

    /**
     * @param player
     * @return
     */
    Player save(Player player);

}
