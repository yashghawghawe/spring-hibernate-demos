/**
 * 
 */
package com.yash.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.model.Player;
import com.yash.repository.PlayerRepository;

/**
 * @author yash.ghawghawe
 *
 */
@Repository
public class PlayerDaoImpl implements PlayerDao {
    
    @Autowired
    private PlayerRepository playerRepo;

    @Override
    public Player save(Player player) {
        Player p = playerRepo.save(player);
        return p;
    }

}
