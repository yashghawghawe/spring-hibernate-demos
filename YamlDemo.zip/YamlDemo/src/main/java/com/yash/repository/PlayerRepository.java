/**
 * 
 */
package com.yash.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.yash.model.Player;

/**
 * @author yash.ghawghawe
 *
 */
public interface PlayerRepository extends CrudRepository<Player , Integer> ,JpaRepository<Player, Integer>{

}
