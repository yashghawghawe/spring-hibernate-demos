/**
 * 
 */
package com.yash.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dao.PlayerDao;
import com.yash.model.Player;

import javax.transaction.Transactional;

/**
 * @author yash.ghawghawe
 *
 */
@Service
@Transactional
public class PlayerServiceImpl implements PlayerService {
    
    @Autowired
    private PlayerDao playerDao;

    @Override
    public Player save(Player player) {
        Player p = playerDao.save(player);
        return p;
    }

}
