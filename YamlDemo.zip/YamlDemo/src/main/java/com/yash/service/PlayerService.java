/**
 * 
 */
package com.yash.service;

import com.yash.model.Player;

/**
 * @author yash.ghawghawe
 *
 */
public interface PlayerService {

    /**
     * @param player
     * @return
     */
    Player save(Player player);

}
